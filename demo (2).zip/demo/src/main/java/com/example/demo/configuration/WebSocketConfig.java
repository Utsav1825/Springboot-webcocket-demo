package com.example.demo.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer{
	
	//This end point will be used by the client app(app.js) to connect to STOMP
	// to connect with server
	@Override
	public void registerStompEndpoints(StompEndpointRegistry registry) {
		registry.addEndpoint("/stomp-endpoint");
		  registry.addEndpoint("/stomp-endpoint").setAllowedOrigins("*").withSockJS();
	}
	
	
	@Override
	public void configureMessageBroker(MessageBrokerRegistry registry) {
		//This we enable an in-memory message broker to carry the messages back to client on destinations prefixed with "/topic
		// to subscribe so that we can receive messages
		registry.enableSimpleBroker("/topic");
		//This end point is what the controller method is mapped to handle
		registry.setApplicationDestinationPrefixes("/app");
		
	}

}
