package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Chat;
import com.example.demo.model.Message;


public interface ChatService {

	Chat addMessages(Message message);
	List<String> getAllVendors(String clientEmailId) throws Exception;
	List<String> getAllClients(String vendorEmailId) throws Exception;
	List<Message> getAllMessages(String clientEmailId, String vendorEmailId);
}

