package com.example.demo.controller;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Message;
import com.example.demo.service.ChatServiceImpl;

@RestController
@RequestMapping("/api/v3")
public class MessageController {
	
	@Autowired
	private ChatServiceImpl service;
	
	@Autowired
	private SimpMessagingTemplate template;
	
	@MessageMapping("/chat")
	public void sendMessage(@Payload Message message) {
		message.setCurrentDateTime(LocalDateTime.now());
		service.addMessages(message);
		//path to which the subcriber will subscribe to receive messages
		template.convertAndSend("/topic"+message.getToId(), message);
	}

	
}

